<?php get_header();?>


	<div id="main">
	
	<!-- add in the left sidebar -->	
	<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
	
	<div id="content">
		<?php if ($posts) { ?>
			<div class="page-info"><em style="float: left;">archived posts: </em></div>
			<h3><?php echo single_cat_title(); ?></h3>
			
			<?php foreach ($posts as $post) : start_wp(); ?>				
				<div class="page">
					<?php require('posts.php'); ?>
					<?php comments_template(); // Get wp-comments.php template ?>
				</div>
			<?php endforeach; ?>
			<p align="center"><?php posts_nav_link() ?></p>		
		<?php } else { ?>
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
		<?php } ?>
			
	</div>
	
	<?php get_sidebar(); ?>

<?php get_footer()?>
</div>
</div>
</body>
</html>