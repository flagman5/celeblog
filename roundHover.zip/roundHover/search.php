<?php /* Don't remove this line. */ require('./wp-blog-header.php'); ?>
<?php get_header() ?>

	<div id="main">
	
	<!-- add in the left sidebar -->	
	<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
	
	<div id="content">	
	<?php if ($posts) { ?>	
		<?php $post = $posts[0]; /* Hack. Set $post so that the_date() works. */ ?>
		<div class="page-info"><em style="float:left;">search results:</em></div>
		<h3><?php echo $s; ?></h3>			
						
		<?php foreach ($posts as $post) : start_wp(); ?>				
			<?php require('posts.php'); ?>
		<?php endforeach; ?>
		<div class="navigation">
			<div class="alignleft"><?php posts_nav_link('','','&laquo; Older Entries') ?></div>
			<div class="alignright"><?php posts_nav_link('','Newer Entries &raquo;','') ?></div>
		</div>	
	<?php } else { ?>
		<h2 class="center">Not Found</h2>
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
	<?php } ?>		
	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
</div>
</div>
</body>
</html>
