<?php get_header()?>	


<div id="main">
	
	<!-- add in the left sidebar -->	
	<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
	
	<div id="content">
			<?php if ($posts) : foreach ($posts as $post) : start_wp(); ?>
			<div class="post">
				<?php require('posts.php'); ?>
				<!-- take out the // to uncomment -->
				<?php comments_template();?> <!-- UNCOMMENT THIS TO TAKE COMMENTS OUT OF THE FOOTER - NOTE YOU
																						WILL ALSO NEED TO DELETE THINGS IN footer.php WHAT TO DELETE IS NOTED -->
			</div>
			<?php endforeach; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
			<?php endif; ?>
		<p align="center"><?php posts_nav_link() ?></p>		
	</div>
	
<?php get_sidebar() ?>		
	
<?php  get_footer();?>

</div>

</div>
</body>
</html>