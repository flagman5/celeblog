<?php get_header(); ?>

<div id="main">

	<!-- add in the left sidebar -->	
	<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
	<div id="content">
		
		<?php if ($posts) : foreach ($posts as $post) : start_wp(); ?>
			
			<div class="post">
				<?php require('posts.php'); ?> <!-- keeping it clean in here, check post.php for posts.php formating -->
				<?php comments_template(); ?>
			</div>
			
			<?php endforeach; else: ?>
			
			<p>
			<?php _e('Sorry, no posts matched your criteria.'); ?>
			</p>
			
			<?php endif; ?>
		
		<p align="center"><?php posts_nav_link() ?></p>		
	</div>
	
	<?php get_sidebar(); ?>
		
	<?php get_footer(); ?>

</div>

</div>
</body>
</html>