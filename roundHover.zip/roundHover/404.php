<?php get_header(); ?>
	<div id="content">
		<div id="main">
			<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
			<div class="post">
				<p class="post-title"><em>Not Found<?php edit_post_link('[edit this]'); ?></em> Server on <?php echo date('d M Y h:m a'); ?></p>
				<h2>Oooops...Where did you get such a link ?</h2>
				<div class="post-content">
					<p>The Server tried all of its options before returning this page. <br/> Are you sure you spelled the link correctly ? You may want to search through our Archives and find what you are looking far.</p>
				</div>
				<p class="post-footer">Don't loose the hope just yet...</p>
			</div>					
	</div>
		<?php get_sidebar() ;?>
		<?php get_footer(); ?>
		</div>
		
	</div>
</body>
</html>