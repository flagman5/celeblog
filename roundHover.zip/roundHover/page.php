<?php get_header()?>
<div id="main">

	<!-- add in the left sidebar -->	
	<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
	
	<div id="content">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		<div class="page">
			<div class="page-info"><em><?php edit_post_link('[edit this]'); ?></em>
			<h2 class="page-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h2>
			</div>
			
			<div class="page-content">
				<?php the_content(); ?>
	
				<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
	
			</div>
		</div>
		
	  <?php endwhile; endif; ?>
	</div>
	
	<?php get_sidebar(); ?>

	<?php get_footer();?>

</div>

</div>
</body>
</html>




