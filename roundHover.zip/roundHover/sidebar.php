<div id="sidebar">

	
		
<!-- 125 x 125 AD SPOTS - SPONSORS -->
<!-- if you don't want this just comment it out -->
<h3>Sponsors</h3>
<div class="ads">
<!-- 	CHANGE OUT LINKS AND IMAGES WITH YOUR OWN SPONSORS -->
	<a href="#"><img src="http://freeyourdesign.com/images/adspot.jpg" alt="add" class="left" /></a>
	<a href="#"><img src="http://freeyourdesign.com/images/adspot.jpg" alt="add" /></a>
	<br />
	<a href="#"><img src="http://freeyourdesign.com/images/adspot.jpg" alt="add" class="left" /></a>
	<a href="#"><img src="http://freeyourdesign.com/images/adspot.jpg" alt="add" /></a>
</div>
<div class="sidebarBtm"></div>

<!-- sidebar1 dynamic sidebar -->
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar1') ) : else : ?>
 
 	<!-- IF YOU DON'T USE THE DYNAMIC SIDEBAR WIDGET THIS IS WHAT WILL SHOW UP -->
	
	<!-- Search -->
	<h3>Search</h3>
	<ul>
		<li>
			<div class="search">
					<form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<input type="text" value="<?php echo wp_specialchars($s, 1); ?>" size="15" name="s" id="s" />
					<input type="submit" id="searchsubmit" value="<?php _e('Search'); ?>" />
					</form>
			</div>
		</li>
	</ul>
	<div class="sidebarBtm"></div>
			
	<h3><?php _e('Categories'); ?></h3>
		<ul><?php wp_list_cats('optioncount=1');    ?></ul>
	<div class="sidebarBtm"></div>

	<!-- RECENT POSTS -->
			<h3><?php _e('Recent Posts'); ?></h3>
				<ul><?php wp_get_archives('type=postbypost&limit=6'); ?></ul>
		<div class="sidebarBtm"></div>
	
	<h3><?php _e('Archives'); ?></h3>
		<ul><?php wp_get_archives('type=monthly&show_post_count=true'); ?></ul>
		<div class="sidebarBtm"></div>
		
	<!-- RECENT COMMENTS -->
		<h3><?php _e('Recent Comments'); ?></h3>
			<ul>
				<li style="border: none;">&nbsp;</li>
				<?php get_recent_comments(6,5); //shows 6 recent comments, each with first 5 words ?>
			</ul>
	<div class="sidebarBtm"></div>

	
	
	<h3><?php _e('Links'); ?></h3>
			<ul><?php get_links('-1', '<li>', '</li>', ' '); ?></ul>
			<div class="sidebarBtm"></div>
					
	<?php if(is_home()) { ?>
				
		<h3><?php _e('Meta'); ?></h3>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a></li>
					<li><a href="http://jigsaw.w3.org/css-validator/check/referer" title="valid css">Valid CSS</a></li>
					<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>">WordPress</a></li>
					<?php wp_meta(); ?>
				</ul>
				<div class="sidebarBtm"></div>
	<?php } ?>
		
		
<?php endif; ?>
</div>