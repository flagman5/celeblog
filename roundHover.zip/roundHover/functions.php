<?php
if ( function_exists('register_sidebar') )
	register_sidebar(array('name'=>'sidebar1',
		'before_widget' => '', 
		'after_widget' => '<div class="sidebarBtm"></div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>', 
	));
	register_sidebar(array('name'=>'sidebar2',
		'before_widget' => '', 
		'after_widget' => '<div class="sidebarBtm"></div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>', 
	));
	
	
	//make my customized tag cloud widget
	//if there is one by this name get rid of it
	if ( function_exists('unregister_sidebar_widget') )
	{
		unregister_sidebar_widget( __('newTag Cloud') );	
	}
	//bring it back clean and new
	if ( function_exists('register_sidebar_widget') )
	{
		register_sidebar_widget(__('newTag Cloud'), 'hargism_tags');
	}
	
	if(function_exists('unregister_sidebar_widget'))
	{
		unregister_sidebar_widget(__('wp_widget_search'));
	}
	if(function_exists('register_sidebar_widget'))
	{
		register_sidebar_widget(__('search bar'), 'mySearch');
	}

//for the above creation of my customized tag cloud widget	
function hargism_tags() {?>
	<!-- tag cloud -->
		<div class="sideWhole">
			<h3>Tag Cloud</h3>
				<ul>
					<li><?php wp_tag_cloud(''); ?></li>
				</ul>
				<div class="sidebarBtm"></div>
		</div>
<?php }	

//for above creationof customized search widget
function mySearch() {?>
	<h3>Search</h3>
	<ul>
	<li>
	<div class="search">
			<form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<input type="text" value="<?php echo wp_specialchars($s, 1); ?>" size="15" name="s" id="s" />
			<input type="submit" id="searchsubmit" value="<?php _e('Search'); ?>" />
			</form>
	</div>
	</li>
	</ul>
	<div class="sidebarBtm"></div>
<?php }



function get_recent_comments($no_comments = 5, $comment_num_of_words = 4, $before = '<li>', $after = '</li>') 
{
        global $wpdb, $tablecomments, $tableposts;
        
        $request = "SELECT ID, comment_ID, comment_content, comment_author FROM $tableposts, $tablecomments WHERE $tableposts.ID=$tablecomments.comment_post_ID AND post_status = 'publish' ";
        $request .= "AND comment_approved = '1' ORDER BY $tablecomments.comment_date DESC LIMIT $no_comments";
        $comments = $wpdb->get_results($request);
        
       	$output = '';
       	if($comments) {
        foreach ($comments as $comment) 
        {
                $comment_author = stripslashes($comment->comment_author);
                $comment_content = strip_tags($comment->comment_content);
                $comment_content = stripslashes($comment_content);
                $words=split(" ",$comment_content);
                $comment_excerpt = join(" ",array_slice($words,0,$comment_num_of_words));
                $permalink = get_permalink($comment->ID)."#comment-".$comment->comment_ID;
                $output .= $before . '<strong>' . $comment_author . '</strong>: <a href="' . $permalink;
                $output .= '" title="'.__('Comment by','c4m').' ' . $comment_author.'">' . $comment_excerpt . '...</a>' . $after;
        }
        }
        echo $output;

}

//GsL98DGtpo0W
 