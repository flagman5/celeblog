
<div class="post-info">
	
	<h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h2>
	
	<p class="post-more">
		written by <?php the_author(); ?> on 
		<?php the_time('M d, Y'); ?>
	</p>
</div>

<div class="post-content">
	<?php the_content(); ?>
		
	<div class="post-info">
		<?php wp_link_pages(); ?>											
	</div>
	
	<!--
		<?php trackback_rdf(); ?>
	-->
	
	<!-- the comment stat at bottom of post -->
	<div class="post-footer"><em>Posted in <?php the_category(' &amp;');?> <?php edit_post_link('[edit this]'); ?></em><?php comments_popup_link('No Comments Yet', '1 Comment', '|%| Comments'); ?></div>

</div>

