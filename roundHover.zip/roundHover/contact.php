<?php
/*
Template Name: Contact
*/
?>
<?php get_header(); ?>
<div id="main">

	<!-- add in the left sidebar -->	
	<?php include(TEMPLATEPATH . '/sidebarLeft.php'); ?>
	
	<div id="content"> 		   
    	<?php if (have_posts()) : ?>
			<?php while (have_posts()) : the_post(); ?>
				<div class="page">
				<?php
					//validate email adress
					function is_valid_email($email)
					{
  						return (eregi ("^([a-z0-9_]|\\-|\\.)+@(([a-z0-9_]|\\-)+\\.)+[a-z]{2,4}$", $email));
					}
					//clean up text
					function clean($text)
					{
						return stripslashes($text);
					}
					//encode special chars (in name and subject)
					function encodeMailHeader ($string, $charset = 'UTF-8')
					{
    					return sprintf ('=?%s?B?%s?=', strtoupper ($charset),base64_encode ($string));
					}

					$bw_name    = (!empty($_POST['bw_name']))    ? $_POST['bw_name']    : "";
					$bw_email   = (!empty($_POST['bw_email']))   ? $_POST['bw_email']   : "";
					$bw_url     = (!empty($_POST['bw_url']))     ? $_POST['bw_url']     : "";
					$bw_message = (!empty($_POST['bw_message'])) ? $_POST['bw_message'] : "";
					$bw_message = clean($bw_message);
					$error_msg = "";
					$send = 0;
					if (!empty($_POST['submit'])) {			
						$send = 1;
						if (empty($bw_name) || empty($bw_email) || empty($bw_message)) {
							$error_msg.= "<p><strong>Please fill in all required fields.</strong></p>\n";
							$send = 0;
						}
						if (!is_valid_email($bw_email)) {
							$error_msg.= "<p><strong>Your email adress failed to validate.</strong></p>\n";
							$send = 0;
						}
					}
					if (!$send) { ?>
						<div class="page-info"><em><?php edit_post_link('[edit this]'); ?></em>
						<h2 class="page-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2></div>
						<div class="post-content">
							<?php
								the_content();
								echo $error_msg;	
							?>
							<form method="post" action="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" id="contactform">
								<fieldset>
									
									<p><input type="text" id="bw_name" name="bw_name" class="text" value="<?php echo $bw_name ;?>" /><strong>Name</strong></p>
									
									<p><input type="text" id="bw_email" name="bw_email" class="text" value="<?php echo $bw_email ;?>" /><strong>Email</strong></p>
									<p><input type="text" id="bw_url" name="bw_url" class="text" value="<?php echo $bw_url ;?>" /><strong>Website</strong></p>
									
									<p><strong>Message</strong><br/>				
									<textarea id="bw_message" name="bw_message" value="<?php echo $bw_message ;?>"></textarea>
									</p>
									<input type="submit" id="submit" name="submit" value="Send Message" />		
								</fieldset>
							</form>
						</div>
					<?php
					} else {
						$displayName_array	= explode(" ",$bw_name);
						$displayName = htmlentities(utf8_decode($displayName_array[0]));
			
						$header  = "MIME-Version: 1.0\n";
						$header .= "Content-Type: text/plain; charset=\"utf-8\"\n";
						$header .= "From:" . encodeMailHeader($bw_name) . "<" . $bw_email . ">\n";
						$email_subject	= "[" . get_settings('blogname') . "] " . encodeMailHeader($bw_name);
						$email_text		= "From......: " . $bw_name . "\n" .
							  "Email.....: " . $bw_email . "\n" .
							  "Url.......: " . $bw_url . "\n\n" .
							  $bw_message;

						if (@mail(get_settings('admin_email'), $email_subject, $email_text, $header)) {
							echo "<h2>Hey " . $displayName . ",</h2><p>thanks for your message! I'll get back to you as soon as possible.</p>";
					}
					}
					?>
				<?php endwhile; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php get_sidebar(); ?>
	<?php get_footer(); ?>
</div>

